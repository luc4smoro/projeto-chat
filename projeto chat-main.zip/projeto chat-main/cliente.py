import socket  # Importa a biblioteca socket para permitir a conexão de rede com o servidor
import threading  # Importa threading para receber mensagens em segundo plano, sem bloquear a interface

# -------------------- Configurações do Cliente --------------------
HOST = '127.0.0.1'  # Define o endereço IP do servidor (localhost) para conexões locais
PORTA = 9999        # Define a porta onde o servidor estará escutando

# -------------------- Função para Enviar Mensagem --------------------
def enviar_mensagem():
    # Loop contínuo para enviar mensagens até o usuário decidir sair
    while True:
        mensagem = input()  # Lê a mensagem do usuário no console
        cliente.send(mensagem.encode())  # Envia a mensagem para o servidor, convertendo-a em bytes

        if mensagem.lower() == 'sair':  # Se a mensagem for "sair", o cliente deseja encerrar a conexão
            cliente.close()  # Fecha o socket do cliente, terminando a conexão com o servidor
            break  # Encerra o loop de envio de mensagens, pois o cliente saiu do chat

# -------------------- Função para Receber Mensagens --------------------
def receber_mensagens():
    # Loop contínuo para receber mensagens do servidor enquanto a conexão estiver ativa
    while True:
        try:
            # Recebe uma mensagem do servidor
            mensagem = cliente.recv(1024).decode()  # Recebe até 1024 bytes do servidor e decodifica de bytes para string
            print(mensagem)  # Exibe a mensagem recebida no console
        except:
            # Em caso de erro (por exemplo, se o servidor fechar a conexão), o loop termina
            break  # Encerra o loop de recebimento de mensagens

# -------------------- Conexão Inicial com o Servidor --------------------
# Cria o socket TCP/IP para o cliente
cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Conecta o cliente ao servidor usando o endereço IP e a porta especificados
cliente.connect((HOST, PORTA))

# -------------------- Identificação do Usuário --------------------
# Solicita o nome do usuário para identificação no chat e o envia ao servidor
cliente.send(input("Digite seu nome: ").encode())

# -------------------- Thread para Receber Mensagens --------------------
# Inicia uma thread que executa a função receber_mensagens em segundo plano,
# permitindo que o cliente continue enviando mensagens sem bloqueios
threading.Thread(target=receber_mensagens, daemon=True).start()

# -------------------- Loop para Enviar Mensagens --------------------
# Inicia o loop de envio de mensagens no console
enviar_mensagem()
