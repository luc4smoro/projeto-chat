import socket  # Importa a biblioteca socket para permitir conexões de rede
import threading  # Importa threading para gerenciar conexões simultâneas em threads separadas

# -------------------- Configurações do Servidor --------------------
HOST = '127.0.0.1'  # Define o endereço IP do servidor (localhost) para conexões locais
PORTA = 9999        # Define a porta onde o servidor estará escutando conexões

# Dicionário que armazenará os clientes conectados (nome do cliente e socket)
clientes = {}

# -------------------- Função de Gerenciamento de Clientes --------------------
def gerenciar_cliente(conexao):
    # -------------------- Identificação do Cliente --------------------
    nome = conexao.recv(1024).decode()  # Recebe o nome do cliente e decodifica de bytes para string
    clientes[nome] = conexao            # Adiciona o nome e socket do cliente ao dicionário `clientes`
    print(f"{nome} entrou no chat.")    # Exibe no console do servidor que o cliente entrou no chat

    # -------------------- Loop para Receber Mensagens --------------------
    while True:
        try:
            mensagem = conexao.recv(1024).decode()  # Recebe a mensagem do cliente e decodifica de bytes para string

            # -------------------- Saída do Cliente --------------------
            if mensagem.lower() == 'sair':  # Verifica se a mensagem é "sair" (cliente deseja sair do chat)
                print(f"{nome} saiu do chat.")  # Exibe no servidor que o cliente saiu do chat
                break  # Encerra o loop para este cliente

            # -------------------- Unicast (Mensagem Privada) --------------------
            elif mensagem.startswith('@'):  # Verifica se a mensagem começa com '@' (indica mensagem privada)
                destino, mensagem_privada = mensagem[1:].split(' ', 1)  # Separa o nome do destinatário e a mensagem
                if destino in clientes:  # Verifica se o destinatário está conectado
                    # Envia a mensagem privada para o destinatário
                    clientes[destino].send(f"[Privado] {nome}: {mensagem_privada}".encode())  # Codifica e envia a mensagem

            # -------------------- Broadcast (Mensagem Pública) --------------------
            else:
                # Envia a mensagem para todos os clientes conectados, exceto o remetente
                for cliente, sock in clientes.items():  # Itera sobre todos os clientes conectados
                    if cliente != nome:  # Verifica se o cliente atual não é o remetente
                        sock.send(f"{nome}: {mensagem}".encode())  # Envia a mensagem para o cliente

        except:
            break  # Se ocorrer um erro (ex: cliente desconectado), encerra o loop para este cliente

    # -------------------- Encerramento da Conexão --------------------
    conexao.close()        # Fecha a conexão com o cliente
    del clientes[nome]     # Remove o cliente do dicionário `clientes`

# -------------------- Configuração do Socket do Servidor --------------------
servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # Cria um socket TCP/IP
servidor.bind((HOST, PORTA))  # Associa o socket ao endereço IP e à porta configurados
servidor.listen()             # Coloca o socket em modo de escuta, aguardando conexões
print(f"Servidor rodando em {HOST}:{PORTA}")  # Exibe no console que o servidor está ativo e pronto para conexões

# -------------------- Loop Principal do Servidor --------------------
while True:
    # Aceita uma nova conexão de cliente
    conexao_cliente, _ = servidor.accept()  # Aceita a conexão de um cliente e obtém o socket e endereço do cliente
    # Inicia uma nova thread para lidar com o cliente conectado, permitindo conexões simultâneas
    threading.Thread(target=gerenciar_cliente, args=(conexao_cliente,)).start()
